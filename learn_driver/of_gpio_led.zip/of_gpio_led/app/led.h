#ifndef _LED_HEAD_H_
#define _LED_HEAD_H_ 

#define DEV_LED_TYPE 'k'
#define DEV_LED_ON  _IO(DEV_LED_TYPE,0x13)
#define DEV_LED_OFF _IO(DEV_LED_TYPE,0x14)

#endif 
